﻿using Asm2_PH46062;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2
{
    public class Test
    {
        public Servies ser;
        public SinhVien sv;
        [SetUp]
        public void Setup()
        {
            ser = new Servies();
        }
        public void Test_ThemSinhVien_1()
        {
            sv = new SinhVien("ID001", "Nguyễn Văn A", "L000", "Kiểm thử", "SV001");
            ser.ThemSv(sv);
            Assert.Contains(sv, ser.sinhViens);
        }
    }
}
//[Test]
//[TestCase("ID001", "Nguyễn Văn A", "L000", "Kiểm thử", "SV001")]
//[TestCase("ID002", "Nguyễn Văn B", "L000", "Kiểm thử", "SV002")]
//[TestCase("ID003", "Nguyễn Văn C", "L000", "Kiểm thử", "SV003")]
//[TestCase("ID004", "Nguyễn Văn D", "L000", "Kiểm thử", "SV004")]
//[TestCase("ID005", "Nguyễn Văn E", "L000", "Kiểm thử", "SV005")]
//[TestCase("ID006", "Nguyễn Văn G", "L000", "Kiểm thử", "SV006")]
//[TestCase("ID007", "Nguyễn Văn H", "L000", "Kiểm thử", "SV007")]
//[TestCase("ID008", "Nguyễn Văn K", "L000", "Kiểm thử", "SV008")]
//[TestCase("ID009", "Nguyễn Văn J", "L000", "Kiểm thử", "SV009")]
//[TestCase("ID000", "Nguyễn Văn O", "L000", "Kiểm thử", "SV0010")]
