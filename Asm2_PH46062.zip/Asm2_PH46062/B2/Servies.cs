﻿using Asm2_PH46062;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2
{
    public class Servies
    {
        public List<SinhVien> sinhViens = new List<SinhVien>();
        public void ThemSv(SinhVien sinhvien)
        {
            sinhViens.Add(sinhvien);
        }
        public void SuaSv(string id, string hoten, string malop, string tenlop, string masv)
        {
            var sv = sinhViens.FirstOrDefault(x => x.ID == id);
            if (sv != null)
            {
                sv.ID = id;
                sv.Hoten = hoten;
                sv.Malop = malop;
                sv.Tenlop = tenlop;
                sv.Masv = masv;
            }
        }
        public void XoaSv(string id)
        {
            sinhViens.RemoveAll(x => x.ID == id);
        }
    }
}
