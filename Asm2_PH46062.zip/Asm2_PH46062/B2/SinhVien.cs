﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asm2_PH46062
{
    public class SinhVien
    {
        public SinhVien(string iD, string hoten, string malop, string tenlop, string masv)
        {
            ID = iD;
            Hoten = hoten;
            Malop = malop;
            Tenlop = tenlop;
            Masv = masv;
        }

        public string  ID { get; set; }
        public string Hoten { get; set; }
        public string Malop { get; set; }
        public string Tenlop { get; set; }
        public string Masv { get; set; }
    }
}
