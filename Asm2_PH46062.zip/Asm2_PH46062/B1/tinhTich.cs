﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asm2_PH46062
{
    public class tinhTich
    {
        [Test]
        [TestCase(0, 0, 0)]
        [TestCase(1, 0, 0)]
        [TestCase(1, 2, 2)]
        [TestCase(3, -2, -6)]
        [TestCase(4, 4, 16)]
        [TestCase(-5, 2, -10)]
        [TestCase(-6, -9, 54)]
        [TestCase(7, 2, 14)]
        [TestCase(int.MaxValue, -1, int.MaxValue * -1)]
        [TestCase(int.MinValue, 1, int.MinValue)]
        public void TinhTich(int x, int y, int z)
        {
            var result = x * y;
            Assert.That(result, Is.EqualTo(z));
        }
    }
}
