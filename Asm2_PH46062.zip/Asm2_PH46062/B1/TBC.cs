﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asm2_PH46062
{
    public class TBC
    {
        [Test]
        public void Test_TBC_1()
        {
            int[] arr1 = { 1, 2, 3, 4, 5 };
            int total = 0;
            double avg = 0;
            for(int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(3));
        }
        [Test]
        public void Test_TBC_2()
        {
            int[] arr1 = { 2,4,6,8,10};
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(6));
        }
        [Test]
        public void Test_TBC_3()
        {
            int[] arr1 = { 1, 3, 5, 7, 9 };
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(5));
        }
        [Test]
        public void Test_TBC_4()
        {
            int[] arr1 = { 1,6,8,2,9 };
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(5));
        }
        [Test]
        public void Test_TBC_5()
        {
            int[] arr1 = { 1,2,8,5,7 };
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(4));
        }
        [Test]
        public void Test_TBC_6()
        {
            int[] arr1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(5));
        }
        [Test]
        public void Test_TBC_7()
        {
            int[] arr1 = { 12, 2, 3, 24, 51, 100 };
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(32));
        }
        [Test]
        public void Test_TBC_8()
        {
            int[] arr1 = { 15, 2, 32, 43, 5, 88, 71 };
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(36));
        }
        [Test]
        public void Test_TBC_9()
        {
            int[] arr1 = {73,83,12,16,34,65,23};
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(43));
        }
        [Test]
        public void Test_TBC_10()
        {
            int[] arr1 = { -1, -84, -23, 54, -74, -97, 55, -6, 40 };
            int total = 0;
            double avg = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                total += arr1[i];
            }
            avg = total / arr1.Length;
            Assert.That(avg, Is.EqualTo(-15));

        }
    }
}
