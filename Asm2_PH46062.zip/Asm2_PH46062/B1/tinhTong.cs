﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asm2_PH46062
{
    public class tinhTong
    {
        [Test]
        [TestCase(0,0,0)]
        [TestCase(1,0,1)]
        [TestCase(1,1,2)]
        [TestCase(-3,2,-1)]
        [TestCase(4,4,8)]
        [TestCase(-5,6,1)]
        [TestCase(6,9,15)]
        [TestCase(7,-2,5)]
        [TestCase(int.MaxValue, -1,int.MaxValue -1)]
        [TestCase(int.MinValue,1,int.MinValue + 1)]
        public void TinhTong(int x, int y, int z)
        {
            var result = x + y;
            Assert.That(result, Is.EqualTo(z));
        }

    }
}
